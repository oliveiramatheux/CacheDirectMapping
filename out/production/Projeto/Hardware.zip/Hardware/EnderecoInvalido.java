package Hardware;

public class EnderecoInvalido extends Exception {
    private final int ender;

    public EnderecoInvalido(int ender) {
        this.ender = ender;
    }

    public String toString() {
        return "Endereço " + ender + " é inválido";
    }
}
