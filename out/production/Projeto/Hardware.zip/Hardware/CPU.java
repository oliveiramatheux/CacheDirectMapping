package Hardware;

public class CPU {
    private final Cache cache;
    private final IO es;
    private int PC = 0;

    public CPU (Cache cache, IO es){
        this.cache = cache;
        this.es = es;
    }

    public void Run(int ender) throws EnderecoInvalido {
        PC = ender;

        int regA = cache.Read(PC++);
        int regB = cache.Read(PC++);

        for (int i = regA; i <= regB; ++i) {
            cache.Write(i, i-regA+1);
            es.Output("\tcpu> " + i + " -> " + cache.Read(i));
        }
    }
}
