package Hardware;

public class RAM implements Memory{
    private final int tam;
    private final int[] memory;

    public RAM(int k) {
        this.tam = (int) Math.pow(2,k);
        this.memory = new int[this.tam];
    }

    @Override
    public int Read(int ender) throws EnderecoInvalido{
        if (ehValido(ender))
            return this.memory[ender];
        else
            throw new EnderecoInvalido(ender);
    }

    @Override
    public void Write(int ender, int palavra) throws EnderecoInvalido{
        if (ehValido(ender))
            this.memory[ender] = palavra;
        else
            throw new EnderecoInvalido(ender);
    }

    protected boolean ehValido(int e) {
        return (e >= 0 && e < tam);
    }
}
