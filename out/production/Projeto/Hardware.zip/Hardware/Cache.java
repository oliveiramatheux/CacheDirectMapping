package Hardware;

public class Cache implements Memory {
    private final RAM ram;
    private final int[] cache;
    private int inicio;
    private boolean alterado = false;

    public Cache(int tam, RAM ram) {
        this.ram = ram;
        this.cache = new int[tam];
    }


    private void copyRam(int ender) throws EnderecoInvalido {
        inicio = ender;
        for (int i = 0; i < cache.length; ++i) {
            cache[i] = ram.Read(ender + i);
        }
    }

    private void writeRam() throws EnderecoInvalido {
        for (int i = 0; i < cache.length; ++i) {
            ram.Write(inicio + i, cache[i]);
        }
    }

    private boolean ehValido(int ender) {
        return ender - inicio >= 0 && ender - inicio < cache.length;
    }

    @Override
    public int Read(int ender) throws EnderecoInvalido {
        if (ehValido(ender)) {
            return cache[ender - inicio];
        }
        if (alterado) {
            writeRam();
            alterado = false;
        }
        copyRam(ender);
        return cache[ender - inicio];
    }

    @Override
    public void Write(int ender, int palavra) throws EnderecoInvalido {
        if (ehValido(ender)) {
            cache[ender - inicio] = palavra;
            alterado = true;
        } else {
            if (alterado) {
                writeRam();
                alterado = false;
            }
            copyRam(ender);
            cache[ender - inicio] = palavra;
        }
    }
}
