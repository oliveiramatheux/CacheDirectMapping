package Hardware;

public interface Memory {
    abstract int Read(int ender) throws EnderecoInvalido;
    abstract void Write(int ender, int palavra) throws EnderecoInvalido;
}
